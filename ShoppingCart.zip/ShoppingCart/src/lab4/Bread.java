package lab4;

class Bread extends Product {
    Bread(String provider, Integer idProduct, Integer price, Integer stock) {
        super(provider, idProduct, price, stock);
    }

    public boolean equals(Object o) {
        if (o == this) return true;

        if (!(o instanceof Bread)) {
            return false;
        }

        Bread bread = (Bread) o;

        return getIdProduct().equals(bread.getIdProduct());
    }
}
