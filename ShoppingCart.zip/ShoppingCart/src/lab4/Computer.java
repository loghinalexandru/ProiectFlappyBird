package lab4;

class Computer extends Product {
    Computer(String provider, Integer idProduct, Integer price, Integer stock) {
        super(provider, idProduct, price, stock);
    }

    public boolean equals(Object o) {
        if (o == this) return true;

        if (!(o instanceof Computer)) {
            return false;
        }

        Computer computer = (Computer) o;

        return getIdProduct().equals(computer.getIdProduct());
    }
}
