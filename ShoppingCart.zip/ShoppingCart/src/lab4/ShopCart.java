package lab4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ShopCart {
    private Map<Product, Integer> products;
    private Integer totalSum;

    public ShopCart() {
        products = new HashMap<>();
        totalSum = 0;
    }

    public Integer getTotalSum() {
        return totalSum;
    }

    public List<Map.Entry<Product, Integer>> getProducts() {
        return new ArrayList<>(products.entrySet());
    }

    public void addProduct(Product product, Integer number) {
        if(product.getStock() < number) {
            System.out.println("Not enough items in stock. No products added!");
            return;
        }

        if(products.containsKey(product)) {
            totalSum -= getPriceForProduct(product);
            products.put(product, products.get(product) + number);
        } else {
            products.put(product, number);
        }

        totalSum += getPriceForProduct(product);

    }

    public void removeProduct(Product product) {
        if(!products.containsKey(product)) {
            return;
        }

        removeProduct(product, products.get(product));
    }

    public void removeProduct(Product product, Integer number) {
        if(!products.containsKey(product)) {
            return;
        }

        if(products.get(product) < number) {
            System.out.println("Not enough products in shopcart to remove.");
            return;
        }

        totalSum -= getPriceForProduct(product);
        products.put(product, products.get(product) - number);
        totalSum += getPriceForProduct(product);
    }

    public void itemsSold(){
        for(Map.Entry<Product, Integer> item : products.entrySet()) {
            item.getKey().getSold();
        }
    }

    public void buyShoppingCart(){
        for(Map.Entry<Product, Integer> item : products.entrySet()) {
            if(item.getKey().getStock() < item.getValue()){
                System.out.println("Product with ID : " + item.getKey().getIdProduct() + " is out of stock , removing automatically...");
                this.removeProduct(item.getKey());
            }
        }
        products.entrySet().removeIf(product -> getNumberOfProducts(product.getKey()) == 0);

        if(products.isEmpty()){
            System.out.println("Empty cart...");
        }
        else{
            for(Map.Entry<Product, Integer> item : products.entrySet()) {
                item.getKey().remove(item.getValue());
            }
            System.out.println(this);
        }

    }


    public Integer getNumberOfProducts(Product p){
        if(!products.containsKey(p)){
            return 0;
        }
        return products.get(p);
    }

    /**
     *
     * @param product
     * @return the price with discount applied
     */
    private Integer getPriceForProduct(Product product) {
        if(products.get(product) <= 5) {
            return product.getPrice() * products.get(product);
        } else if(products.get(product) <= 10) {
            return product.getPrice() * products.get(product) * 8 / 10;
        } else {
            return product.getPrice() * products.get(product) * 4 / 10;
        }
    }

    public String toString() {
        StringBuilder ret = new StringBuilder();

        ret.append("Products:\n");
        for(Map.Entry<Product, Integer> item : products.entrySet()) {
            ret.append(item.getKey().getProvider()).append(' ').append(item.getValue()).append('\n');
        }

        ret.append("Total price: ").append(getTotalSum()).append('\n');

        return ret.toString();
    }
}
