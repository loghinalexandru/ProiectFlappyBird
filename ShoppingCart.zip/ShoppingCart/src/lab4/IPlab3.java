package lab4;

import java.util.*;

public class IPlab3 {
    public static void main(String[] args) {
        Computer computer = new Computer("Asus", 23, 40, 10);
        Bread bread = new Bread("Vel Pitar", 10, 6, 100);
        Water water = new Water("Borsec", 99, 8, 100);

        ShopCart shopCart = new ShopCart();

        shopCart.addProduct(computer, 4);
        shopCart.addProduct(water, 6);

        System.out.println(shopCart);

        shopCart.addProduct(computer, 3);
        shopCart.addProduct(bread, 50);

        System.out.println(shopCart);

        shopCart.removeProduct(computer, 20);

        System.out.println(shopCart);

        shopCart.removeProduct(bread, 25);

        shopCart.addProduct(bread , 75);

        ShopCart secondShopCart = new ShopCart();

        secondShopCart.addProduct(bread , 50);
        System.out.println(secondShopCart);


        System.out.println(shopCart);
       // shopCart.itemsSold();
        shopCart.buyShoppingCart();
        secondShopCart.buyShoppingCart();
       // shopCart.itemsSold();
    }
}

