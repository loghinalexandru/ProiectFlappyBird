package lab4;

abstract class Product {
    private String provider;
    private Integer idProduct;
    private Integer price;
    private Integer stock;
    private Integer sold;

    Product(String provider, Integer idProduct, Integer price, Integer stock) {
        this.provider = provider;
        this.idProduct = idProduct;
        this.price = price;
        this.stock = stock;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public void remove(Integer number) {
        this.stock -= number;
        this.sold -= number;
    }

    public void add(Integer number) {
        this.stock += number;
        this.sold += number;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public Integer getIdProduct() {
        return idProduct;
    }

    public void setIdProduct(Integer idProduct) {
        this.idProduct = idProduct;
    }

    public int hashCode() {
        return getIdProduct();
    }
}
