package lab4;

class Water extends Product {
    Water(String provider, Integer idProduct, Integer price, Integer stock) {
        super(provider, idProduct, price, stock);
    }

    public boolean equals(Object o) {
        if (o == this) return true;

        if (!(o instanceof Water)) {
            return false;
        }

        Water water = (Water) o;

        return getIdProduct().equals(water.getIdProduct());
    }
}
